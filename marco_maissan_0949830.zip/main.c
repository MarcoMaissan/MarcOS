#include <alloc.h>

/*
 *
 * BertOS - I/O assignment
 * src/main.c
 *
 * Copyright (C) 2019 Bastiaan Teeuwen <bastiaan@mkcl.nl>
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301,
 * USA.
 *
 */

void main(void)
{
    int *j = malloc(sizeof(int));
    int *k = malloc(sizeof(int));
    int *l = malloc(sizeof(int));
    int *m = malloc(sizeof(int));
    int *n = malloc(sizeof(char[10]));
    int *o = malloc(sizeof(char[10]));
    printf("size of char = %d\n", sizeof(char[10]));

    printf("Mem location of j = %p\n", j);
    printf("Mem location of k = %p\n", k);
    printf("Mem location of l = %p\n", l);
    printf("Mem location of m = %p\n", m); 

    printf("Nieuw = %p\n", n);
    printf("Nieuw = %p\n", o);


    free(k);
    free(n);
    free(o);

    int* p = malloc(sizeof(int));
    *p = 4;

    printf("Mem location of p = %p\n", p);
    printf("Succesfully stored a value of %d\n", *p);
}
